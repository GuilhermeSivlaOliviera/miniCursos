const express = require("express")
const router = express.Router();
const Client = require('../models/client'); 
const mongoose = require('mongoose');

//rota principal
router.get('/', function(req, res){
    res.render("admin/index")
})

//rotas para listar os cursos
router.get('/cursos', function(req, res){
    res.render("admin/cursos")
})
//rotas para cadastrar os cursos
router.get('/cursos/add', function(req, res){
    res.render("admin/addcursos")
})
//editar
router.put('/:admincursoId', (req, res, next)=>{
    const id = req.params.clientUpdate;
    const client = req.params.body;
    Client.findByIdAndUpdate(id,req.body,{new:true})
    .exec()
    .then(doc => {
        res.status(200).json({
            message: "Usuario atualizado com sucesso.",
            produtoAtualizado: doc
        });
    })
    .catch(err =>{
        res.status(500).json({error:err});
    })
  
  });
//deletar
router.delete('/:adimincursoDelet',(req, res, next)=> {
    const id = req.params.clientDelet;
        Client.findByIdAndDelete(id)
        .exec()
        .then(doc=>{
           res.status(200).json(doc);
           message: 'DELETE Request para /usuario'
})
.catch(err =>{
    res.status(500).json({erro:err});
})
});

//exportando o router
    module.exports = router