const express= require('express');
const router= express.Router();
const Curso = require('../models/cursos'); 
const mongoose = require('mongoose');
//adicionar
router.get('/curso',(req, res, next)=> {
    Curso.find()
    .exec()
    .then(doc=>{
        res.status(200).json(doc);
    })
    .catch(err=>{
        res.status(500).json({
            error:err
        })
    });
});
//deletar
router.delete('/:cursoDelet',(req, res, next)=> {
    const id = req.params.cursoDelet;
        Curso.findByIdAndDelete(id)
        .exec()
        .then(doc=>{
           res.status(200).json(doc);
           message: 'DELETE Request para /Curso'
})
.catch(err =>{
    res.status(500).json({erro:err});
})
});
//
router.post('/curso',(req, res, next)=> {
    const curso = new Curso({
        _id: new mongoose.Types.ObjectId(),
        nome: req.body.nome,
        preco: req.body.preco
    });
    curso.save()
    .then(result => {
        res.status(201).json({
            message: 'POST Request para /Curso',
            CursoCriado: curso 
        });
    })
    .catch(err=> {
        res.status(500).json({
            eror:err
        });
    });
   
});
//5e87800f5cf0de10e0a07058 / 5e8780035cf0de10e0a07056 / 5e877fbc5cf0de10e0a07054/ / 5e8781bb442b684f009ad47d /
//pegar curso especifico
router.get('/:cursoId',(req, res, next)=> {
    const id = req.params.cursoId;
    Curso.findById(id)
    .exec()
    .then(doc=>{
        res.status(200).json(doc);
    })
    .catch(err =>{
        res.status(500).json({erro:err});
    })
});
 //atualizar curso
router.put('/:cusoId', (req, res, next)=>{
  const id = req.params.cursoUpdate;
  const curso = req.params.body;
  Curso.findByIdAndUpdate(id,req.body,{new:true})
  .exec()
  .then(doc => {
      res.status(200).json({
          message: "Curso atualizado com sucesso.",
          cursoAtualizado: doc
      });
  })
  .catch(err =>{
      res.status(500).json({error:err});
  })

});

module.exports = router;