const mongoose = require('mongoose');

const clientSchema= mongoose.Schema({
    id:mongoose.Schema.Types.ObjectId,
    nome: String,
    senha: Number
});

module.exports=mongoose.model('Curso', clientSchema);