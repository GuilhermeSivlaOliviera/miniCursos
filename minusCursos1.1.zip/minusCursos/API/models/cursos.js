const mongoose = require('mongoose');

const cursoSchema= mongoose.Schema({
    id:mongoose.Schema.Types.ObjectId,
    nome: String,
    preco: Number
});

module.exports=mongoose.model('Curso', crusoSchema);